//
//#include <iostream>
//#include "List.h"
//#include "PSLL.h"
//#include <string>
//using namespace std;
//using namespace COP3530;
//
//int main() {
//
//    //SSLL
//    cout<<endl<<endl;
//    cout<<"PSLL STARTS HERE"<<endl<<"--------------------"<<endl;
//    PSLL <int> list;
//
//    list.insert(24, 2);
//    list.insert(244, 1);
//    list.insert(1234, 0);
//    list.insert(5, 3);
//    list.insert(543, 1);
//    
//    list.insert(56, 5);
//    list.insert(76543,5);
//    list.insert(254, 3);
//    list.push_back(100);
//    list.push_front(1);
//
//    int* contents = list.contents();
//
//    for (int i =0; i!=10; i++) {
//        cout<<contents[i]<<endl;
//    }
//
//    // list.replace(6, 10);
//    // cout<<list.item_at(10);
//    cout<<list.peek_front()<<endl;
//    cout<<list.peek_back()<<endl;
//
//
//
//
//    list.print(cout);
//    cout<<endl<< list.contains(100, equals_function)<<endl;
//    cout<<list.remove(0);
//    list.print(cout);
//}
//
